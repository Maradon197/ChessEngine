#ifndef ATTACKDETECTOR
#define ATTACKDETECTOR

#include "DataTypes.hpp"
#include "Bitboard.hpp"

bool isSquareAttacked(Square sq, Color byColor, const Position& pos);
Bitboard attackersToSquare(Square sq, Color byColor, const Position& pos);

bool isInCheck(Color color, const Position& pos);
Bitboard checkersToColor(Color color, const Position& pos);

#endif
