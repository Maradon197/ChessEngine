#ifndef DATATYPES
#define DATATYPES

#include <cstdint>
#include <cstddef>
//All memory layouts count up from the LSB


//MEMORY LAYOUT OF BITBOARD:
// one bit per square
// when a val is 1 == occupied (usually)
//	Squares:	Maps to:
//	A1			0
//	H1			7
//	A2			8
//		  ...
//	A8			56
//	H8			63	
using Bitboard = std::uint64_t;

//MEMORY LAYOUT OF MOVE:
// 0-5:		source square (0-63)
// 6-11:	destination square (0-63)
// 12:		is Castle
// 13:		is En Passant
// 14:		is Promotion
// 15-17:	promotion piece type (0 for no promotion)
// 18:		is capture
// 19-31:	unused
using Move = std::uint32_t;

constexpr std::size_t MAX_MOVES = 256;

struct MoveList {
	Move moves[MAX_MOVES];
	std::size_t count = 0;
};

//MEMORY LAYOUT OF CASTLING INFO:
// 0 / 1:	allow White long (0) / short (1) castle
// 2 / 3:	allow Black long (2) / short (3) castle
// 4+:		unused
using CastlingInfo = std::uint8_t;

constexpr CastlingInfo NO_CASTLE = 0b0000;
constexpr CastlingInfo SHORT_CASTLE = 0b1010;
constexpr CastlingInfo LONG_CASTLE = 0b0101;

constexpr CastlingInfo REVOKE_WHITE_LONG_CASTLE = 0b1110;
constexpr CastlingInfo REVOKE_WHITE_SHORT_CASTLE = 0b1101;
constexpr CastlingInfo REVOKE_BLACK_LONG_CASTLE = 0b1011;
constexpr CastlingInfo REVOKE_BLACK_SHORT_CASTLE = 0b0111;

constexpr CastlingInfo REVOKE_WHITE_CASTLES = 0b1100;
constexpr CastlingInfo REVOKE_BLACK_CASTLES = 0b0011;

//MEMORY LAYOUT OF SQUARE:
// 0-5:		source square (0-63)
// 6:		flag: is EP allowed? (NO_SQUARE)
// 7+:		should be zero! otherwise BB logic is inefficient (2^x downshift)
using Square = std::uint8_t;
constexpr Square NO_SQUARE = 64;
constexpr Square WHITE_LEFT_ROOK_HOME_SQUARE = 0;
constexpr Square WHITE_RIGHT_ROOK_HOME_SQUARE = 7;
constexpr Square BLACK_LEFT_ROOK_HOME_SQUARE = 56;
constexpr Square BLACK_RIGHT_ROOK_HOME_SQUARE = 63;

//simple integer counting up moves for ply / fullmove clock
//the hypothetical maximum is ~8k, so std::uint8_t is not sufficient
//even though more than 255 moves are extremely unlikely
using Clock = std::uint16_t;

enum Color {WHITE, BLACK};
constexpr Color operator!(Color color) {//opposite color
	return color == Color::WHITE ? Color::BLACK : Color::WHITE;
}

enum PieceType {PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, NONE};

struct Position {
	Bitboard pieces[2][6];

	Bitboard total_occupancy;
	Bitboard color_occupancy[2];
	
	Color side_to_move;
	CastlingInfo castling_rights;
	Square ep_square;

	Clock reversible_halfmove_clock;
	Clock fullmove_counter;
};

#endif
